/**
 * 
 */
package com.capg.airline.service;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.dao.FlightInfDaooImpl;
import com.capg.airline.dao.IFlightInfoDao;

/**
 * @author CAPG
 *
 */
public class FlightInfoImpl implements IFlightInfoService {

	IFlightInfoDao iFlightInfoDao;

	/**
	 * 
	 */
	public FlightInfoImpl() {
		// TODO Auto-generated constructor stub
		iFlightInfoDao = new FlightInfDaooImpl();
	}

	@Override
	public FlightInformation getAirplaneInfo(FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		flightInformation = iFlightInfoDao.getAirplaneInfo(flightInformation);
		return flightInformation;
	}

	@Override
	public FlightInformation fetchFlight(FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		return iFlightInfoDao.fetchFlight(flightInformation);

	}

	@Override
	public FlightInformation addFlight() {
		// TODO Auto-generated method stub

		return iFlightInfoDao.addFlight();
	}

	@Override
	public FlightInformation deleteFlight(String flightNo) {
		// TODO Auto-generated method stub
		return iFlightInfoDao.deleteFlight(flightNo);
	}

	@Override
	public FlightInformation updateFlight(String flightNo) {
		// TODO Auto-generated method stub
		return iFlightInfoDao.updateFlight(flightNo);
	}

}
