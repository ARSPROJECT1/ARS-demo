/**
 * 
 */
package com.capg.airline.dao;

import com.capg.airline.bean.UsersBean;

/**
 * @author CAPG
 *
 */
public interface IUserDao {
	public UsersBean getAuthentication(UsersBean usersBean);

	public UsersBean createUser(UsersBean usersBean);
}
