/**
 * 
 */
package com.capg.airline.dao;

import java.sql.Connection;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import javax.naming.NamingException;

import com.capg.airline.bean.FlightInformation;
import com.capg.airline.exception.AirlineException;
import com.cpag.airline.util.DBUtil;

/**
 * @author CAPG
 *
 */
public class FlightInfDaooImpl implements IFlightInfoDao {

	Logger logger = Logger.getRootLogger();
	Connection connection;

	/**
	 * 
	 */
	public FlightInfDaooImpl() {
		// TODO Auto-generated constructor stub
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	//------------------------ 1.Airline Book --------------------------
	/*******************************************************************************************************
				 - Function Name	:	getAirplaneInfo()
				 - Input Parameters	:   fligtInformation
				 - Return Type		:	AirportBean
				 - Throws		    :   AirlineException
				 - Author		    :   Team 5
				 - Creation Date	:	16/10/2017
				 - Description		:	getting flightinformation
	 ********************************************************************************************************/
	@Override
	public FlightInformation getAirplaneInfo(FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int count = 0;
		try {
			connection = DBUtil.getConnection();

			String query = "select * from flightinformation where dep_city='" + flightInformation.getArrCity()
					+ "' and arr_city='" + flightInformation.getDepCity() + "' and airline='"
					+ flightInformation.getAirline() + "'";
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();

			// System.out.println("Size"+resultSet.getFetchSize());

			resultSet.next();

			flightInformation.setFlightNo(resultSet.getString(1));
			flightInformation.setAirline(resultSet.getString(2));
			flightInformation.setDepDate(resultSet.getString(5));
			flightInformation.setArrDate(resultSet.getString(6));
			// System.out.println(flightInformation.getArrDate());
			flightInformation.setDepTime(resultSet.getString(7));
			flightInformation.setArrTime(resultSet.getString(8));
			flightInformation.setFirstSeats(resultSet.getInt(9));
			// System.out.println(flightInformation.getFirstSeats()+"FFDFDFDF");
			flightInformation.setBussSeats(resultSet.getInt(11));
			flightInformation.setFirstSeatFare(resultSet.getDouble(10));
			flightInformation.setBussSeatsFare(resultSet.getDouble(12));

		} catch (NamingException e) {
			// TODO Auto-generated catch block

		} catch (SQLException e) {
			// TODO Auto-generated catch block

		} catch (Exception e) {
			logger.error("Error in retriving flight data");

		}

		return flightInformation;

	}
	//------------------------ 1.Airline Book --------------------------
		/*******************************************************************************************************
					 - Function Name	:	fetchFlight()
					 - Input Parameters	:   fligtInformation
					 - Return Type		:	AirportBean
					 - Throws		    :   AirlineException
					 - Author		    :   Team 5
					 - Creation Date	:	16/10/2017
					 - Description		:	fetching flightinformation
		 ********************************************************************************************************/
	@Override
	public FlightInformation fetchFlight(FlightInformation flightInformation) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		int count = 0;
		try {
			connection = DBUtil.getConnection();

			String query = "select * from flightinformation where flightno='" + flightInformation.getFlightNo() + "'";
			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();

			// System.out.println("Size"+resultSet.getFetchSize());
			resultSet.next();
			// flightInformation.setFlightNo(resultSet.getString(1));
			flightInformation.setAirline(resultSet.getString(2));
			flightInformation.setDepCity(resultSet.getString(3));
			flightInformation.setArrCity(resultSet.getString(4));
			flightInformation.setDepDate(resultSet.getString(5));
			flightInformation.setArrDate(resultSet.getString(6));
			// System.out.println(flightInformation.getArrDate());
			flightInformation.setDepTime(resultSet.getString(7));
			flightInformation.setArrTime(resultSet.getString(8));
			flightInformation.setFirstSeats(resultSet.getInt(9));
			// System.out.println(flightInformation.getFirstSeats()+"FFDFDFDF");
			flightInformation.setBussSeats(resultSet.getInt(11));
			flightInformation.setFirstSeatFare(resultSet.getDouble(10));
			flightInformation.setBussSeatsFare(resultSet.getDouble(12));
			System.out.println("Flight Information is as follows:::");
			System.out.println("Flight No-" + flightInformation.getFlightNo() + "     Airline-"
					+ flightInformation.getAirline() + "      Dep. City-" + flightInformation.getDepCity());
			System.out.println("Arr. City-" + flightInformation.getArrCity() + "     Dep. Date-"
					+ flightInformation.getDepDate() + "      Arr. Date-" + flightInformation.getArrDate());
			System.out.println("Dep Time-" + flightInformation.getDepTime() + "     Arr. Time-"
					+ flightInformation.getArrTime() + "      First Seats-" + flightInformation.getFirstSeats());
			System.out.println("First Seat Fare-" + flightInformation.getFirstSeatFare() + "     Business Seat-"
					+ flightInformation.getBussSeats() + "      Buss. Seat Fare-"
					+ flightInformation.getBussSeatsFare());
		} catch (NamingException e) {
			// TODO Auto-generated catch block

		} catch (SQLException e) {
			// TODO Auto-generated catch block

		} catch (Exception e) {

			logger.error("Error in fetching flight details.");
		}
		return flightInformation;

	}
	//------------------------ 1.Airline Book --------------------------
			/*******************************************************************************************************
						 - Function Name	:	addFlight()
						 - Return Type		:	AirportBean
						 - Throws		    :   AirlineException
						 - Author		    :   Team 5
						 - Creation Date	:	16/10/2017
						 - Description		:	adding flightinformation
			 ********************************************************************************************************/
	@Override
	public FlightInformation addFlight() {
		// TODO Auto-generated method stub
		FlightInformation flightInformation = new FlightInformation();
		PreparedStatement preparedStatement = null;
		try {

			connection = DBUtil.getConnection();
			String query1 = "insert into flightInformation  values(?,?,?,?,?,?,?,?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(query1);
			System.out.println("Enter Flight Number");
			flightInformation.setFlightNo(new Scanner(System.in).nextLine());
			preparedStatement.setString(1, flightInformation.getFlightNo());
			System.out.println("Enter Flight Airline");
			flightInformation.setAirline(new Scanner(System.in).nextLine());
			preparedStatement.setString(2, flightInformation.getAirline());
			System.out.println("Enter Dep City");
			flightInformation.setDepCity(new Scanner(System.in).nextLine());
			preparedStatement.setString(3, flightInformation.getDepCity());
			System.out.println("Enter Arr City");
			flightInformation.setArrCity(new Scanner(System.in).nextLine());
			preparedStatement.setString(4, flightInformation.getArrCity());
			System.out.println("Enter Dep Date");
			flightInformation.setDepDate(new Scanner(System.in).nextLine());
			preparedStatement.setString(5, flightInformation.getDepDate());
			System.out.println("Enter Arr Date");
			flightInformation.setArrDate(new Scanner(System.in).nextLine());
			preparedStatement.setString(6, flightInformation.getArrDate());
			System.out.println("Enter Dep Time");
			flightInformation.setDepTime(new Scanner(System.in).nextLine());
			preparedStatement.setString(7, flightInformation.getDepTime());
			System.out.println("Enter Arr Time");
			flightInformation.setArrTime(new Scanner(System.in).nextLine());
			preparedStatement.setString(8, flightInformation.getArrTime());
			System.out.println("Enter First Seats");
			flightInformation.setFirstSeats(new Scanner(System.in).nextInt());
			preparedStatement.setInt(9, flightInformation.getFirstSeats());
			System.out.println("Enter First Seat Fare");
			flightInformation.setFirstSeatFare(new Scanner(System.in).nextDouble());
			preparedStatement.setDouble(10, flightInformation.getFirstSeatFare());
			System.out.println("Enter Business Seats");
			flightInformation.setBussSeats(new Scanner(System.in).nextInt());
			preparedStatement.setInt(11, flightInformation.getBussSeats());
			System.out.println("Enter Business Seat Fare");
			flightInformation.setBussSeatsFare(new Scanner(System.in).nextDouble());
			preparedStatement.setDouble(12, flightInformation.getBussSeatsFare());
			preparedStatement.executeUpdate();
			System.out.println("Flight Added ::Thank you");
		} catch (NamingException | SQLException | AirlineException e) {
			// TODO Auto-generated catch block
			logger.error("Flight is not added..");

		}

		return flightInformation;
	}
	//------------------------ 1.Airline Book --------------------------
			/*******************************************************************************************************
						 - Function Name	:	deleteFlight()
						 - Input Parameters	:   flightNo
						 - Return Type		:	AirportBean
						 - Throws		    :   AirlineException
						 - Author		    :   Team 5
						 - Creation Date	:	16/10/2017
						 - Description		:	deleting flightinformation
			 ********************************************************************************************************/
	@Override
	public FlightInformation deleteFlight(String flightNo) {
		// TODO Auto-generated method stub
		FlightInformation flightInformation = new FlightInformation();
		PreparedStatement preparedStatement = null;
		try {
			connection = DBUtil.getConnection();
			String query1 = "delete from flightinformation where flightno=?";
			preparedStatement = connection.prepareStatement(query1);
			preparedStatement.setString(1, flightNo);
			boolean r = preparedStatement.execute();
			if(r == false){
				System.out.println("Flight Deleted ::Thank you");
			}
			logger.info("Flight deleted successfully.");
		} catch (NamingException | SQLException | AirlineException e) {
			e.printStackTrace();
			logger.error("Flight is not deleted..");

		}
		return flightInformation;
	}
	//------------------------ 1.Airline Book --------------------------
	/*******************************************************************************************************
				 - Function Name	:	updateFlight()
				 - Return Type		:	FlightInformation
				 - Throws		    :   AirlineException
				 - Author		    :   Team 5
				 - Creation Date	:	16/10/2017
				 - Description		:	updating flightinformation
	 ********************************************************************************************************/
	@Override
	public FlightInformation updateFlight(String flightNo) {
		// TODO Auto-generated method stub
		FlightInformation flightInformation = new FlightInformation();
		PreparedStatement preparedStatement = null;
		try {
			flightInformation.setFlightNo(flightNo);
			connection = DBUtil.getConnection();
			String query1 = "update flightinformation set DEP_DATE=?, ARR_DATE=?,DEP_TIME=?,ARR_TIME=?,FIRSTSEATS=?, FIRSTSEATFARE=?,BUSSSEATS=?,BUSSSEATFARE=? where FLIGHTNO=?";
			preparedStatement = connection.prepareStatement(query1);
			System.out.println("Enter Dep Date");
			flightInformation.setDepDate(new Scanner(System.in).nextLine());
			preparedStatement.setString(1, flightInformation.getDepDate());
			System.out.println("Enter Arr Date");
			flightInformation.setArrDate(new Scanner(System.in).nextLine());
			preparedStatement.setString(2, flightInformation.getArrDate());
			System.out.println("Enter Dep Time");
			flightInformation.setDepTime(new Scanner(System.in).nextLine());
			preparedStatement.setString(3, flightInformation.getDepTime());
			System.out.println("Enter Arr Time");
			flightInformation.setArrTime(new Scanner(System.in).nextLine());
			preparedStatement.setString(4, flightInformation.getArrTime());
			System.out.println("Enter First Seats");
			flightInformation.setFirstSeats(new Scanner(System.in).nextInt());
			preparedStatement.setInt(5, flightInformation.getFirstSeats());
			System.out.println("Enter First Seat Fare");
			flightInformation.setFirstSeatFare(new Scanner(System.in).nextDouble());
			preparedStatement.setDouble(6, flightInformation.getFirstSeatFare());
			System.out.println("Enter Business Seats");
			flightInformation.setBussSeats(new Scanner(System.in).nextInt());
			preparedStatement.setInt(7, flightInformation.getBussSeats());
			System.out.println("Enter Business Seat Fare");
			flightInformation.setBussSeatsFare(new Scanner(System.in).nextDouble());
			preparedStatement.setDouble(8, flightInformation.getBussSeatsFare());
			preparedStatement.setString(9, flightInformation.getFlightNo());
			preparedStatement.executeUpdate();
			System.out.println("Flight Updated ::Thank you");
			logger.info("Updated successfully.");
		} catch (NamingException | SQLException | AirlineException e) {
			// TODO Auto-generated catch block
			logger.error(" Not updated.");
		}
		return flightInformation;
	}

}
