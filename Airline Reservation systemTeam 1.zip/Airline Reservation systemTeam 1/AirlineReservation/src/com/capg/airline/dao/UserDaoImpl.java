/**
 * 
 */
package com.capg.airline.dao;

import java.sql.Connection;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import javax.naming.NamingException;

import com.capg.airline.bean.UsersBean;
import com.capg.airline.exception.AirlineException;
import com.cpag.airline.util.DBUtil;

/**
 * @author CAPG
 *
 */
public class UserDaoImpl implements IUserDao {

	Logger logger = Logger.getRootLogger();
	Connection con;

	/**
	 * @throws AirlineException
	 * @throws SQLException
	 * @throws NamingException
	 * 
	 */
	public UserDaoImpl() throws NamingException, SQLException, AirlineException {
		// TODO Auto-generated constructor stub
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	@Override
	public UsersBean getAuthentication(UsersBean usersBean) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			Connection connection = DBUtil.getConnection();

			String query = "select role,mobile_no from users where  USERNAME=?";

			preparedStatement = connection.prepareStatement(query);
			
			preparedStatement.setString(1, usersBean.getUserName());
			
			resultSet = preparedStatement.executeQuery();
	
			// System.out.println(resultSet.getFetchSize());
			if(resultSet.next()==false)
				throw new Exception("No such user");
	
			// System.out.println(resultSet.getString(3));
			usersBean.setRole(resultSet.getString(1));
			usersBean.setMobileNo(resultSet.getLong(2));
			logger.info("Admin is authenticated.");

		} catch (NamingException e) {
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block

		} catch (Exception e) {
			e.printStackTrace();
		}
		return usersBean;
	}

	@Override
	public UsersBean createUser(UsersBean usersBean) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		Connection connection;
		try {
			connection = DBUtil.getConnection();
			String query = "Insert into users values(?,?,?,?)";

			preparedStatement = connection.prepareStatement(query);
			System.out.println("Enter Username");
			usersBean.setUserName(new Scanner(System.in).nextLine());
			preparedStatement.setString(1, usersBean.getUserName());
			System.out.println("Enter Password");
			usersBean.setPassWord(new Scanner(System.in).nextLine());
			preparedStatement.setString(2, usersBean.getPassWord());
			System.out.println("Enter Role");
			usersBean.setRole(new Scanner(System.in).nextLine());
			preparedStatement.setString(3, usersBean.getRole());
			System.out.println("Enter Mobile No.");
			usersBean.setMobileNo(new Scanner(System.in).nextLong());
			preparedStatement.setLong(4, usersBean.getMobileNo());
			preparedStatement.executeUpdate();
			System.out.println("User Added");
		} catch (NamingException | SQLException | AirlineException e) {
			// TODO Auto-generated catch block

		}

		return usersBean;
	}

}
