/**
 * 
 */
package com.capg.airline.ui;

import java.util.Scanner;

import com.capg.airline.bean.AirportBean;
import com.capg.airline.bean.BookingInformation;
import com.capg.airline.bean.FlightInformation;
import com.capg.airline.bean.UsersBean;
import com.capg.airline.service.AirportServiceImpl;
import com.capg.airline.service.BookingInfoImpl;
import com.capg.airline.service.FlightInfoImpl;
import com.capg.airline.service.IAirportService;
import com.capg.airline.service.IBookingInfoService;
import com.capg.airline.service.IFlightInfoService;
import com.capg.airline.service.IUserService;
import com.capg.airline.service.UserServiceImpl;

/**
 * @author CAPG
 *
 */
public class AirlineMain {
	static IUserService iUserService;
	static IBookingInfoService iBookingInfoService;
	static IFlightInfoService iFlightInfoService;
	static IAirportService iAirportService;

	/**
	 * 
	 */
	public AirlineMain() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UsersBean usersBean = null;
		AirportBean airportBean=new AirportBean();
		BookingInformation bookingInformation = null;
		FlightInformation flightInformation = null;
		int choice = 0;
		while (choice < 5) {
			System.out.println(
					"Welcome\n1--For Admin/Executive Login\n2--Book Ticket\n3--View Reservation\n4--Cancel Booking\n5--Exit");
			choice = new Scanner(System.in).nextInt();
			if (choice == 1) {
				
				/*System.out.println("Enter role");
				String role = new Scanner(System.in).nextLine();*/
				
				
				
				System.out.println("Enter username");
				String userName = new Scanner(System.in).nextLine();
				System.out.println("Enter password");

				String passWord = new Scanner(System.in).nextLine();
				usersBean = new UsersBean();
				usersBean.setUserName(userName);
				usersBean.setPassWord(passWord);
				
			
				/*usersBean.setRole(role);*/
				
				iUserService = new UserServiceImpl();
				usersBean = iUserService.getAuthentication(usersBean);
				
				//System.out.println(usersBean.getRole());

				if (usersBean.getRole().equalsIgnoreCase("admin")) {
					int choice1 = 0;
					while (choice1 < 6) {
						System.out.println("Welcome admin");
						System.out.println(
								"1--Display Flight Details\n2--Add Flight\n3--Cancel Flight\n4--Add new Flight Executive\n5--Manage Flight--\n6--exit");
						choice1 = new Scanner(System.in).nextInt();
						flightInformation = new FlightInformation();
						iFlightInfoService = new FlightInfoImpl();
						if (choice1 == 1) {
							// Displaying Flight
							System.out.println("Enter the Flight Number");
							String flightNo = new Scanner(System.in).nextLine();
							flightInformation.setFlightNo(flightNo);
							flightInformation = iFlightInfoService.fetchFlight(flightInformation);

						} else if (choice1 == 2) {
							// Adding Flight
							flightInformation = iFlightInfoService.addFlight();
						} else if (choice1 == 3) {
							// Cancelling a flight
							System.out.println("Enter Flight Number");
							String flightNo = new Scanner(System.in).nextLine();
							flightInformation = iFlightInfoService.deleteFlight(flightNo);
						} else if (choice1 == 4) {
							// adding new executive
							usersBean = iUserService.createUser(usersBean);

						} else if (choice1 == 5) {
							// managing flight
							System.out.println("Enter Flight Number");
							String flightNo = new Scanner(System.in).nextLine();
							flightInformation = iFlightInfoService.updateFlight(flightNo);

						} else {
							System.exit(0);
						}
					}
				} else if (usersBean.getRole().equalsIgnoreCase("executive")) {
					System.out.println("Enter the Airport Location");
					String location = new Scanner(System.in).nextLine();
					System.out.println("Enter the ");
					System.out.println("Welcome Executive");
					int choice3 = 0;
					while (choice3 < 3) {
						System.out.println("Welcome\n1--Available Flights on Date\n2--Flight Occupancy\n3--Exit");
						flightInformation = new FlightInformation();
						choice3=new Scanner(System.in).nextInt();
						//iFlightInfoService = new FlightInfoImpl();
						iAirportService=new AirportServiceImpl();
						if (choice3 == 1) {
							// Available Flights on the Airport on the date
							System.out.println("Enter the Airport Name"); 
							flightInformation.setDepCity(new Scanner(System.in).nextLine());
							System.out.println("Date in DD-MM-YYYY format");
							flightInformation.setDepDate(new Scanner(System.in).nextLine());
							
							airportBean=iAirportService.fetchDetails(airportBean,flightInformation);

						} else if (choice3 == 2) {
							// Occupancy Details
							System.out.println("Enter Flight Number");
							flightInformation.setFlightNo(new Scanner(System.in).nextLine());
							airportBean=iAirportService.occupancyDetails(airportBean,flightInformation);
						} else {
							System.exit(0);
						}
					}

				}
			} else if (choice == 2) {
				flightInformation = new FlightInformation();
				bookingInformation = new BookingInformation();
				System.out.println("Welcome User");
				System.out.println("Select source and destination cities for flight information ");
				System.out.println("Enter Source City");
				String source = new Scanner(System.in).nextLine();
				flightInformation.setArrCity(source);
				// bookingInformation.setSrcCity(source);
				System.out.println("Enter Destination City");
				String destination = new Scanner(System.in).nextLine();
				flightInformation.setDepCity(destination);
				System.out.println("Enter the Airline");
				String airline = new Scanner(System.in).nextLine();
				flightInformation.setAirline(airline);
				iFlightInfoService = new FlightInfoImpl();
				flightInformation = iFlightInfoService.getAirplaneInfo(flightInformation);

				if (flightInformation.getFirstSeats() <= 0 || flightInformation.getBussSeats() <= 0) {
					System.out.println("Sorry No Seats are Available this time :: Try in another airline");
				} else {
					System.out.println("Flight Number="+flightInformation.getFlightNo());
					System.out.println("Number of First Class Seats Available=" + flightInformation.getFirstSeats());
					System.out.println("Fare for Each Seat=" + flightInformation.getFirstSeatFare());
					System.out.println("Number of Business Class seats Available=" + flightInformation.getBussSeats());
					System.out.println("Fare for Each Seat=" + flightInformation.getBussSeatsFare());

					// bookingInformation.setDestCity(destination);
					iBookingInfoService = new BookingInfoImpl();
					bookingInformation = iBookingInfoService.confirmBooking(bookingInformation, flightInformation);
				}

			} else if (choice == 3) {
				System.out.println("Enter the BookingId");
				String bookingId = new Scanner(System.in).nextLine();
				bookingInformation = new BookingInformation();
				bookingInformation.setBookingId(bookingId);
				iBookingInfoService = new BookingInfoImpl();
				iBookingInfoService.displayBooking(bookingInformation);

			} else if (choice == 4) {
				System.out.println("Enter the BookingId");
				String bookingId = new Scanner(System.in).nextLine();
				/*System.out.println("Enter the No. of seats booked");
				String seatNo = new Scanner(System.in).nextLine();
				*/bookingInformation = new BookingInformation();
				/*flightInformation = new FlightInformation();*/
				bookingInformation.setBookingId(bookingId);
				/*bookingInformation.setSeatNumber(seatNo);*/
				iBookingInfoService = new BookingInfoImpl();
				iBookingInfoService.cancelBooking(bookingInformation, flightInformation);

			}
		}
	}
}
